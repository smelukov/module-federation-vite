export default function Button(): import("react/jsx-runtime").JSX.Element;
